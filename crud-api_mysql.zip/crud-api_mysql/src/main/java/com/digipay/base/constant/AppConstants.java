package com.digipay.base.constant;

public class AppConstants {

	  // Success & UnSuccess
    public static final int SUCCESSFUL = 1;
    public static final int UNSUCCESSFUL = 0;
}

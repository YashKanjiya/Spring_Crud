package com.digipay.base.api.txn_master.model.response;

import java.util.Map;

import com.digipay.base.api.txn_master.model.TXNMaster;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TXNMasterData{


    @JsonProperty("_id")
    private String id;

    @JsonProperty("txn_number")
    private String txnNumber;
    
    @JsonProperty("credit_account_type")
    private int creditAccountType;
    
    @JsonProperty("credit_account_type_id")
    private String creditAccountTypeId;
    
    @JsonProperty("credit_type")
    private int creditType;
    
    @Column(name="credit_type_id")
    private String creditTypeId;
    
    @JsonProperty("credit_amount")
    private Double creditAmount;
    
    @JsonProperty("credit_currency_id")
    private String creditCurrencyId;
    
    @JsonProperty("debit_account_type")
    private int debitAccountType;
    
    @JsonProperty("debit_account_type_id")
    private String debitAccountTypeId;
    
    @JsonProperty("debit_type")
    private int debitType;
    
    @JsonProperty("debit_type_id")
    private String debitTypeId;
    
    @JsonProperty("debit_amount")
    private Double debitAmount;
    
    @JsonProperty("debit_currency_id")
    private String debitCurrencyId;
    
    @JsonProperty("transaction_by")
    private Map<String,Object>transactionBy;
    
    @JsonProperty("txn_code")
    private String txnCode;
    
    @JsonProperty("txn_type")
    private int txnType;
    
    @JsonProperty("txn_date")
    private Long txnDate;
    
    @JsonProperty("txn_status")
    private int txnStatus;
    
    @JsonProperty("note")
    private String note;
    
    @JsonProperty("display_text")
    private Map<String,Object>  displayText;
    
    @JsonProperty("payment_mode")
    private int paymentMode;

    @JsonProperty("txn_amount")
    private Double txnAmount;
    
    @JsonProperty("debit_account_balance")
    private Double debitAccountBalance;
    
    @JsonProperty("credit_account_balance")
    private Double creditAccountBalance;
    
    @JsonProperty("display_end_user")
    private Boolean displayEndUser;
    
    @JsonProperty("meta_data")
    private  Map<String,Object>  metaData;

	public TXNMasterData(TXNMaster txnMaster) 
	{
		
		this.id=txnMaster.getId();
		this.txnNumber=txnMaster.getTxnNumber();
		this.creditAccountType=txnMaster.getCreditAccountType();
		this.creditAccountTypeId=txnMaster.getCreditAccountTypeId();
		this.creditType=txnMaster.getCreditType();
		this.creditCurrencyId=txnMaster.getCreditCurrencyId();
		this.creditTypeId=txnMaster.getCreditTypeId();
		this.creditAmount=txnMaster.getCreditAmount();
		this.debitAccountType=txnMaster.getDebitAccountType();
		this.debitAccountTypeId=txnMaster.getDebitAccountTypeId();
		this.debitType=txnMaster.getDebitType();
		this.debitCurrencyId=txnMaster.getDebitCurrencyId();
		this.debitTypeId=txnMaster.getDebitTypeId();
		this.debitAmount=txnMaster.getDebitAmount();
		this.transactionBy=txnMaster.getTransactionBy();
		this.txnCode=txnMaster.getTxnCode();
		this.txnType=txnMaster.getTxnType();
		this.txnStatus=txnMaster.getTxnStatus();
		this.txnDate=txnMaster.getTxnDate();
		this.note=txnMaster.getNote();
		this.displayText=txnMaster.getDisplayText();
		this.paymentMode=txnMaster.getPaymentMode();
		this.txnAmount=txnMaster.getTxnAmount();
		this.debitAccountBalance=txnMaster.getDebitAccountBalance();
		this.creditAccountBalance=txnMaster.getCreditAccountBalance();
		this.displayEndUser=txnMaster.getDisplayEndUser();
		this.metaData=txnMaster.getMetaData();
	
	}
	

}

package com.digipay.base.api.txn_master.service;

import com.digipay.base.api.commonresponse.CommonAPIDataResponse;
import com.digipay.base.api.txn_master.model.request.DeleteTXNMasterRequest;
import com.digipay.base.api.txn_master.model.request.GetAllTXNMasterRequest;
import com.digipay.base.api.txn_master.model.request.GetTXNMasterRequest;
import com.digipay.base.api.txn_master.model.request.SaveTXNMasterRequest;
import com.digipay.base.api.txn_master.model.request.UpdateTXNMasterRequest;
import com.digipay.base.api.txn_master.model.response.GetAllTXNMasterResponse;
import com.digipay.base.api.txn_master.model.response.GetTXNMasterResponse;
import com.digipay.base.api.txn_master.model.response.SaveTXNMasterResponse;


public interface TXNMasterRepository {

    SaveTXNMasterResponse saveTxnMaster(SaveTXNMasterRequest saveTXNMasterRequest);

    CommonAPIDataResponse updateTXNMaster(UpdateTXNMasterRequest updateTXNMasterRequest);

    CommonAPIDataResponse deleteTxnMaster(DeleteTXNMasterRequest deleteTXNMasterRequest);

    GetTXNMasterResponse getTXNMaster(GetTXNMasterRequest getTXNMasterRequest);

    GetAllTXNMasterResponse AllTXNMasterMaster(GetAllTXNMasterRequest getAllTXNMasterRequest);

}

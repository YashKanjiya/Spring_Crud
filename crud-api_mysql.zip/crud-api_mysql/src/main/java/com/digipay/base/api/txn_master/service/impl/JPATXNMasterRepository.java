package com.digipay.base.api.txn_master.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digipay.base.api.commonresponse.CommonAPIDataResponse;
import com.digipay.base.api.txn_master.dao.TXNMasterQueryDao;
import com.digipay.base.api.txn_master.model.TXNMaster;
import com.digipay.base.api.txn_master.model.request.DeleteTXNMasterRequest;
import com.digipay.base.api.txn_master.model.request.GetAllTXNMasterRequest;
import com.digipay.base.api.txn_master.model.request.GetTXNMasterRequest;
import com.digipay.base.api.txn_master.model.request.SaveTXNMasterRequest;
import com.digipay.base.api.txn_master.model.request.UpdateTXNMasterRequest;
import com.digipay.base.api.txn_master.model.response.GetAllTXNMasterResponse;
import com.digipay.base.api.txn_master.model.response.GetTXNMasterResponse;
import com.digipay.base.api.txn_master.model.response.SaveTXNMasterResponse;
import com.digipay.base.api.txn_master.model.response.TXNMasterData;
import com.digipay.base.api.txn_master.service.TXNMasterRepository;

@Service
public class JPATXNMasterRepository implements TXNMasterRepository {

	@Autowired
	private TXNMasterQueryDao txnMasterQueryDao;
	
	@Override
	public SaveTXNMasterResponse saveTxnMaster(SaveTXNMasterRequest saveTXNMasterRequest) {

		TXNMaster txnMaster=TXNMaster.builder()
				.txnNumber(saveTXNMasterRequest.getTxn_number())
				.creditAccountType(saveTXNMasterRequest.getCredit_account_type())
				.creditAccountTypeId(saveTXNMasterRequest.getCredit_account_type_id())
				.creditType(saveTXNMasterRequest.getCredit_type())
				.creditTypeId(saveTXNMasterRequest.getCredit_type_id())
				.creditAmount(saveTXNMasterRequest.getCredit_amount())
				.creditCurrencyId(saveTXNMasterRequest.getCredit_currency_id())
				.debitAccountType(saveTXNMasterRequest.getDebit_account_type())
				.debitAccountTypeId(saveTXNMasterRequest.getDebit_account_type_id())
				.debitType(saveTXNMasterRequest.getDebit_type())
				.debitTypeId(saveTXNMasterRequest.getDebit_type_id())
				.debitAmount(saveTXNMasterRequest.getDebit_amount())
				.debitCurrencyId(saveTXNMasterRequest.getDebit_currency_id())
				.transactionBy(saveTXNMasterRequest.getTransaction_by())
				.txnCode(saveTXNMasterRequest.getTxn_code())
				.txnType(saveTXNMasterRequest.getTxn_type())
				.txnDate(saveTXNMasterRequest.getTxn_date())
				.txnStatus(saveTXNMasterRequest.getTxn_status())
				.note(saveTXNMasterRequest.getNote())
				.displayText(saveTXNMasterRequest.getDisplay_text())
				.paymentMode(saveTXNMasterRequest.getPayment_mode())
				.txnAmount(saveTXNMasterRequest.getTxn_amount())
				.debitAccountBalance(saveTXNMasterRequest.getDebit_account_balance())
				.creditAccountBalance(saveTXNMasterRequest.getCredit_account_balance())
				.displayEndUser(saveTXNMasterRequest.getDisplay_end_user())
				.metaData(saveTXNMasterRequest.getMeta_data())
				.build();
				
				
				

		txnMasterQueryDao.save(txnMaster);

		SaveTXNMasterResponse saveTXNMasterResponse = new SaveTXNMasterResponse();
		saveTXNMasterResponse.setId(txnMaster.getId());
		saveTXNMasterResponse.setMessage("TXN_MASTER_SAVED_SUCCESSFULLY");
		return saveTXNMasterResponse;
	}

	@Override
	public CommonAPIDataResponse deleteTxnMaster(DeleteTXNMasterRequest deleteTXNMasterRequest) 
	{
		CommonAPIDataResponse commonAPIDataResponse = new CommonAPIDataResponse();

		if (txnMasterQueryDao.findById(deleteTXNMasterRequest.getId()).isPresent()) {
			txnMasterQueryDao.deleteById(deleteTXNMasterRequest.getId());
			commonAPIDataResponse.setMessage("BASE_TXN_MASTER_DATA_DELETED_SUCCESSFULLY");
			commonAPIDataResponse.setCheckValidationFailed(false);
			return commonAPIDataResponse;
        }
		commonAPIDataResponse.setValidationMessage("BASE_TXN_MASTER_DATA_NOT_FOUND");
		commonAPIDataResponse.setCheckValidationFailed(true);
		return commonAPIDataResponse;
	}

  	@Override
  	public GetTXNMasterResponse getTXNMaster(GetTXNMasterRequest getTXNMasterRequest) 
  	 
  	{
  		  GetTXNMasterResponse getDataResponse=new GetTXNMasterResponse();
  	
  	      Optional<TXNMaster> txnmaster= txnMasterQueryDao.findById(getTXNMasterRequest.getId());
  	      
          if (txnmaster.isPresent()) 
          {
        	   
	          	getDataResponse.setMessage("BASE_TXN_MASTER_DATA_FOUND_SUCCESSFULLY");
	          	getDataResponse.setCheckValidationFailed(false);
	            getDataResponse.setTxnMasterData(new TXNMasterData(txnmaster.get()));
	            return getDataResponse;
          }
          getDataResponse.setValidationMessage("TXN_MASTER_DATA_NOT_FOUND");
          getDataResponse.setCheckValidationFailed(true);
          return getDataResponse;
  	 }	
  	
	@Override
  	public CommonAPIDataResponse updateTXNMaster(UpdateTXNMasterRequest updateTXNMasterRequest) 
  	{
		CommonAPIDataResponse commonAPIDataResponse = new CommonAPIDataResponse();

		String id = updateTXNMasterRequest.get_id();
		Optional<TXNMaster> store = txnMasterQueryDao.findById(id);
        
         
		if (store.isPresent()) 
		{
			TXNMaster txnMaster=store.get();
			txnMaster.setId(updateTXNMasterRequest.get_id());
	        txnMaster.setTxnNumber(updateTXNMasterRequest.getTxn_number());
	        txnMaster.setCreditAccountBalance(updateTXNMasterRequest.getCredit_account_balance());
	        txnMaster.setCreditAccountType(updateTXNMasterRequest.getCredit_account_type());
	        txnMaster.setCreditAccountTypeId(updateTXNMasterRequest.getCredit_account_type_id());
	        txnMaster.setCreditAmount(updateTXNMasterRequest.getCredit_amount());
	        txnMaster.setCreditCurrencyId(updateTXNMasterRequest.getCredit_currency_id());
	        txnMaster.setCreditType(updateTXNMasterRequest.getCredit_type());
	        txnMaster.setCreditTypeId(updateTXNMasterRequest.getCredit_type_id());
	        
	        txnMaster.setDebitAccountType(updateTXNMasterRequest.getDebit_account_type());
	        txnMaster.setDebitAccountTypeId(updateTXNMasterRequest.getDebit_account_type_id());
	        txnMaster.setDebitType(updateTXNMasterRequest.getDebit_type());
	        txnMaster.setDebitTypeId(updateTXNMasterRequest.getDebit_type_id());
	        txnMaster.setDebitAmount(updateTXNMasterRequest.getDebit_amount());
	        txnMaster.setDebitCurrencyId(updateTXNMasterRequest.getDebit_currency_id());
	        txnMaster.setDebitAccountBalance(updateTXNMasterRequest.getDebit_account_balance());
	        
	        txnMaster.setTransactionBy(updateTXNMasterRequest.getTransaction_by());
	        txnMaster.setTxnCode(updateTXNMasterRequest.getTxn_code());
	        txnMaster.setTxnType(updateTXNMasterRequest.getTxn_type());
	        txnMaster.setTxnStatus(updateTXNMasterRequest.getTxn_status());
	        txnMaster.setTxnDate(updateTXNMasterRequest.getTxn_date());
	        
	        txnMaster.setNote(updateTXNMasterRequest.getNote());
	        txnMaster.setDisplayText(updateTXNMasterRequest.getDisplay_text());
	        txnMaster.setPaymentMode(updateTXNMasterRequest.getPayment_mode());
	        txnMaster.setTxnAmount(updateTXNMasterRequest.getTxn_amount());
	        txnMaster.setDisplayEndUser(updateTXNMasterRequest.getDisplay_end_user());
	        txnMaster.setMetaData(updateTXNMasterRequest.getMeta_data());
	          
			txnMasterQueryDao.save(txnMaster);
			commonAPIDataResponse.setCheckValidationFailed(true);
			commonAPIDataResponse.setValidationMessage("BASE_TXN_MASTER_MASTER_DATA_UPDATED_SUCCESSFULLY");
			return commonAPIDataResponse;
		} else {
			commonAPIDataResponse.setCheckValidationFailed(false);
			commonAPIDataResponse.setMessage("BASE_TXN_MASTER_MASTER_MASTER_DATA_NOT_FOUND");
			return commonAPIDataResponse;
		}
      }
  	
	@Override
  	public GetAllTXNMasterResponse AllTXNMasterMaster(GetAllTXNMasterRequest getAllTXNMasterRequest) 
  	{
  		GetAllTXNMasterResponse getAllDataResponse = new GetAllTXNMasterResponse();
  		boolean flag=false;
  		List<TXNMaster> criteriaArrayList = new ArrayList<>(100);

		if (!Objects.isNull(getAllTXNMasterRequest.getTxnNumber())
				|| !Objects.isNull(getAllTXNMasterRequest.getCreditAccountType())
				|| !Objects.isNull(getAllTXNMasterRequest.getCreditAccountTypeId())
				|| !Objects.isNull(getAllTXNMasterRequest.getCreditType())
				|| !Objects.isNull(getAllTXNMasterRequest.getCreditTypeId())
				|| !Objects.isNull(getAllTXNMasterRequest.getCreditCurrencyId())
				|| !Objects.isNull(getAllTXNMasterRequest.getDebitAccountType())
				|| !Objects.isNull(getAllTXNMasterRequest.getDebitAccountTypeId())
				|| !Objects.isNull(getAllTXNMasterRequest.getDebitType())
				|| !Objects.isNull(getAllTXNMasterRequest.getDebitTypeId())
				|| !Objects.isNull(getAllTXNMasterRequest.getDebitCurrencyId())
				|| !Objects.isNull(getAllTXNMasterRequest.getTxnCode())
				|| !Objects.isNull(getAllTXNMasterRequest.getTxnType())
				|| !Objects.isNull(getAllTXNMasterRequest.getTxnStatus())
				|| !Objects.isNull(getAllTXNMasterRequest.getPaymentMode()))
        {
        	flag=true;
        	criteriaArrayList.addAll(txnMasterQueryDao.findByAllProperties(getAllTXNMasterRequest.getTxnNumber(),
        			getAllTXNMasterRequest.getCreditAccountType(),
        			getAllTXNMasterRequest.getCreditAccountTypeId(),
        			getAllTXNMasterRequest.getCreditType(),
        			getAllTXNMasterRequest.getCreditTypeId(),
        			getAllTXNMasterRequest.getCreditCurrencyId(),
        			getAllTXNMasterRequest.getDebitAccountType(),
        			getAllTXNMasterRequest.getDebitAccountTypeId(),
        			getAllTXNMasterRequest.getDebitType(),
        			getAllTXNMasterRequest.getDebitTypeId(),
        			getAllTXNMasterRequest.getDebitCurrencyId(),
        			getAllTXNMasterRequest.getTxnCode(),
        			getAllTXNMasterRequest.getTxnType(),
        			getAllTXNMasterRequest.getTxnStatus(),
        			getAllTXNMasterRequest.getPaymentMode()));
        }
		if(!Objects.isNull(getAllTXNMasterRequest.getKeyword()))
        {
        flag=true;
        criteriaArrayList.addAll(txnMasterQueryDao.searchProductsByKeyword(getAllTXNMasterRequest.getKeyword()));        
        }

        if(flag==false)
        {
       	criteriaArrayList.addAll(txnMasterQueryDao.findAll());
        }
        
        if (Objects.isNull(criteriaArrayList) || criteriaArrayList.isEmpty()) 
  		{
  		            getAllDataResponse.setValidationMessage("BASE_TXN_MASTER_DATA_NOT_FOUND");
  		            getAllDataResponse.setCheckValidationFailed(true);
  		            return getAllDataResponse;
  		}
  		getAllDataResponse.setMessage("BASE_TXN_MASTER_DATA_FOUND");
  		List<TXNMasterData> TXNDataList = new ArrayList<>(criteriaArrayList.size());
  		for (TXNMaster i : criteriaArrayList) 
  		{
  			TXNDataList.add(new TXNMasterData(i));	
        }
        getAllDataResponse.setTXNMasterList(TXNDataList);
      
  		return getAllDataResponse;
  	}

}

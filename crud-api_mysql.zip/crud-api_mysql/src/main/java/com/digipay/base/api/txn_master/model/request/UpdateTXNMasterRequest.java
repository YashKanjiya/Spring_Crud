package com.digipay.base.api.txn_master.model.request;

import java.util.Map;

import com.digipay.base.api.commonrequest.CommonAllAPIDataRequest;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UpdateTXNMasterRequest extends CommonAllAPIDataRequest {

    //private Map<String, Object> updateTXNMASTER;
//
	
	@JsonProperty("_id") 
    private String _id;
	  
	@JsonProperty("txn_number")
    private String txn_number;
    
    @JsonProperty("credit_account_type")
    private int credit_account_type;
    
    @JsonProperty("credit_account_type_id")
    private String credit_account_type_id;
    
    @JsonProperty("credit_type")
    private int credit_type;
    
    @JsonProperty("credit_type_id")
    private String credit_type_id;
    
    @JsonProperty("credit_amount")
    private Double credit_amount;
    
    @JsonProperty("credit_currency_id")
    private String credit_currency_id;
    
    @JsonProperty("debit_account_type")
    private int debit_account_type;
    
    @JsonProperty("debit_account_type_id")
    private String debit_account_type_id;
    
    @JsonProperty("debit_type")
    private int debit_type;
    
    @JsonProperty("debit_type_id")
    private String debit_type_id;
    
    @JsonProperty("debit_amount")
    private Double debit_amount;
    
    @JsonProperty("debit_currency_id")
    private String debit_currency_id;
    
    @JsonProperty("transaction_by")
    private Map<String,Object> transaction_by;
    
    @JsonProperty("txn_code")
    private String txn_code;
    
    @JsonProperty("txn_type")
    private int txn_type;
    
    @JsonProperty("txn_date")
    private Long txn_date;
    
    @JsonProperty("txn_status")
    private int txn_status;
    
    @JsonProperty("note")
    private String note;
    
    @JsonProperty("display_text")
    private Map<String,Object>  display_text;
    
    @JsonProperty("payment_mode")
    private int payment_mode;

    @JsonProperty("txn_amount")
    private Double txn_amount;
    
    @JsonProperty("debit_account_balance")
    private Double debit_account_balance;
    
    @JsonProperty("credit_account_balance")
    private Double credit_account_balance;
    
    @JsonProperty("display_end_user")
    private Boolean display_end_user;
    
    @JsonProperty("meta_data")
    private Map<String,Object>meta_data;
    
    public boolean checkBadRequest() 
    {
//        if (Objects.isNull(this.getUpdateTXNMASTER())
//                || this.getUpdateTXNMASTER().isEmpty()) {
//            return true;
//        }
//        if (!this.getUpdateTXNMASTER().containsKey("_id")
//                || Objects.isNull(this.getUpdateTXNMASTER().get("_id"))) {
//            return true;
//        }
        return false;
    }
    
}

package com.digipay.base.api.txn_master.model.response;

import com.digipay.base.api.commonresponse.CommonAPIDataResponse;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class GetTXNMasterResponse extends CommonAPIDataResponse {

    @JsonProperty("txn_master")
    private TXNMasterData txnMasterData;
    
}

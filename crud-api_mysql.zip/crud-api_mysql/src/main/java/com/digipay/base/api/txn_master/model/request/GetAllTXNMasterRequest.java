package com.digipay.base.api.txn_master.model.request;

import com.digipay.base.api.commonrequest.CommonAllAPIDataRequest;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class GetAllTXNMasterRequest extends CommonAllAPIDataRequest {

	// Filter

	 
	    @JsonProperty("txn_number")
		private String txnNumber;
	    
	    @JsonProperty("credit_account_type")
		private Integer creditAccountType;
		
	    @JsonProperty("credit_account_type_id")
		private String creditAccountTypeId;
	    
	    @JsonProperty("credit_type")
		private Integer creditType;
	    
	    @JsonProperty("credit_type_id")
		private String creditTypeId;
	    
	    @JsonProperty("credit_currency_id")
		private String creditCurrencyId;
	    
	    @JsonProperty("debit_account_type")
		private Integer debitAccountType;
	    
	    @JsonProperty("debit_account_type_id")
		private String debitAccountTypeId;
	    
	    @JsonProperty("debit_type")
		private Integer debitType;
	    
	    @JsonProperty("debit_type_id")
		private String debitTypeId;
	    
	    @JsonProperty("debit_currency_id")
		private String debitCurrencyId;
	    
	    @JsonProperty("txn_code")
		private String txnCode;
		
		@JsonProperty("txn_type")
		private Integer txnType;
		
		@JsonProperty("txn_status")
		private Integer txnStatus;
		
		@JsonProperty("payment_mode")
		private Integer paymentMode;

//		search

		private String keyword;

		public boolean checkBadRequest() {
//	        if (StringUtils.isEmpty(this.getCompany_id())) {
//	            return true;
//	        }
			return false;
		}
}
